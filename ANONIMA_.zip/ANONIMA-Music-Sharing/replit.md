# ANONIMA

ANONIMA is an anonymous MP3 sharing board where tracks need two listener votes before they become public.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the Express app (port 3000 by default)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm --filter @workspace/api-server run build` — copy the CommonJS server into `dist/`

## Stack

- pnpm workspaces, Node.js 24
- API and static site: Express 5 with CommonJS `require`
- Uploads: Multer, stored in `.data/anonima-uploads/` outside the executable app directory

## Where things live

- `artifacts/api-server/src/index.js` — Express server and API routes
- `artifacts/api-server/public/` — ANONIMA interface, client fetch logic, and styles
- `artifacts/api-server/uploads/` — runtime MP3 storage

## Architecture decisions

- Track state is intentionally in memory for this simple prototype; uploaded MP3 files remain on disk.
- A track becomes approved after its second anonymous vote.
- The Express `PORT` environment variable is honored, with port 3000 as the local default.

## Product

- Upload an MP3 with a title.
- Review approved and pending tracks.
- Vote pending tracks into the approved list.
- Report and delete tracks.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
