import { useEffect, useState } from "react";

type Track = { id: string; title: string; license: string; url?: string; status?: string; votes?: number; createdAt?: string; };

export default function App() {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [title, setTitle] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState("");

  // GLITCH SULLO SCROLL - per le strisce
  useEffect(() => {
    let t: any;
    const onScroll = () => {
      document.body.classList.add("glitching");
      clearTimeout(t);
      t = setTimeout(() => document.body.classList.remove("glitching"), 400);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    fetch("/api/tracks").then(r=>r.json()).then(setTracks).catch(()=>{});
  }, []);

  const onUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if(!title ||!file) { setStatus("Titolo e file mancanti"); return; }
    setStatus("Caricamento...");
    const fd = new FormData();
    fd.append("title", title);
    fd.append("file", file);
    try {
      const res = await fetch("/api/tracks", { method: "POST", body: fd });
      if(!res.ok) throw new Error();
      setStatus("Caricato — in attesa di approvazione");
      setTitle(""); setFile(null);
      const data = await res.json();
      setTracks(t=>[data,...t]);
    } catch { setStatus("Errore upload"); }
  };

  return (
    <div className="page-shell">
      <header className="site-header">
        <div className="brand-lockup">
          <a className="wordmark" href="/">ANONIMA<span>_</span></a>
          <span className="header-tagline">RAW VAULT — NO NAMES — JUST SOUND</span>
        </div>
        <span className="header-note">VAULT / 001</span>
      </header>

      <section className="intro">
        <p className="eyebrow">— MANIFESTO</p>
        <h1>Suono senza <em>firma.</em></h1>
        <p className="manifesto">Carica. Ascolta. Vota. Nessun profilo, solo tracce.</p>
        <p className="intro-copy">ANONIMA è un vault anonimo. Scrolla e guarda le strisce glitchare — è voluto.</p>
      </section>

      <section className="upload-panel">
        <div className="section-heading">
          <span className="section-number">01</span>
          <h2>Upload</h2>
        </div>
        <form className="upload-form" onSubmit={onUpload}>
          <label className="field">
            <span>Titolo traccia</span>
            <input className="title-input" value={title} onChange={e=>setTitle(e.target.value)} placeholder="UNTITLED_001" />
          </label>
          <label className="file-field">
            <div className="file-copy"><strong>{file? file.name : "Trascina audio o clicca"}</strong><span className="field-hint">MP3 / WAV / MAX 50MB</span></div>
            <span className="file-button">Scegli</span>
            <input type="file" accept="audio/*" onChange={e=>setFile(e.target.files?.[0]||null)} />
          </label>
          <button className="primary-button" type="submit">CARICA NEL VAULT <span>↗</span></button>
          <p className={`form-status ${status.includes("Errore")?"is-error":""}`}>{status}</p>
        </form>
      </section>

      <section className="tracks-section">
        <div className="section-heading tracks-heading">
          <span className="section-number">02</span>
          <h2>Tracce nel vault — {tracks.length}</h2>
        </div>
        <div className="vault-panel">
          <div className="vault-heading">
            <span className="group-label vault-label">APPROVED / RAW</span>
            <p>Scrolla su e giù per vedere l'effetto di rottura sulle due strisce bianca e acido.</p>
            <span className="vault-mark">● LIVE VAULT</span>
          </div>
          {tracks.length===0? <p className="empty-state">Nessuna traccia — sii la prima.</p> :
            tracks.map((tr,i)=>
              <div key={tr.id} className="track-row">
                <span className="track-index">{String(i+1).padStart(2,"0")}</span>
                <div className="track-info">
                  <div className="track-title-line"><h3>{tr.title}</h3><span className="license-tag">{tr.license||"ALL RIGHTS"}</span></div>
                  {tr.url && <audio controls src={tr.url} />}
                </div>
                <div className="track-actions"><span className="approved-mark">●</span></div>
              </div>
            )
          }
        </div>
      </section>

      <footer>
        <span className="footer-copy">ANONIMA © 2026</span>
        <span className="footer-copy">NO TRACKING / NO PROFILE</span>
        <p className="footer-disclaimer">Le strisce bianca e lime sono volute. Il glitch allo scroll è parte del design.</p>
      </footer>
    </div>
  );
}