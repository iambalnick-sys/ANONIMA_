const fs = require("fs");
const path = require("path");

const artifactDir = __dirname;
const distDir = path.join(artifactDir, "dist");

fs.rmSync(distDir, { recursive: true, force: true });
fs.mkdirSync(distDir, { recursive: true });
fs.cpSync(path.join(artifactDir, "src"), distDir, { recursive: true });

process.stdout.write("ANONIMA build complete.\n");