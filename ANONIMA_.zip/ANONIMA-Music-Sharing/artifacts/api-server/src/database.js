const { Pool } = require("pg");

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL is required.");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const trackColumns = [
  "id",
  "title",
  "object_path",
  "content_type",
  "file_size",
  "license",
  "uploader_ip_hash",
  "votes",
  "admin_approved",
  "approved",
  "created_at",
];

function selectTrackColumns(alias) {
  return trackColumns
    .map((column) => (alias ? `${alias}.${column} AS ${column}` : column))
    .join(", ");
}

async function listTracks(viewerIpHash) {
  const result = await pool.query(
    `SELECT ${selectTrackColumns("t")},
       viewer_vote.vote AS viewer_vote
     FROM tracks t
     LEFT JOIN track_votes viewer_vote
       ON viewer_vote.track_id = t.id
      AND viewer_vote.voter_ip_hash = $1
     WHERE t.uploader_ip_hash <> $1
       AND viewer_vote.vote IS DISTINCT FROM 'skip'
     ORDER BY t.approved DESC, t.created_at DESC, t.id DESC`,
    [viewerIpHash],
  );
  return result.rows;
}

async function listAdminTracks() {
  const result = await pool.query(
    `SELECT ${selectTrackColumns()}
     FROM tracks
     WHERE approved = FALSE
     ORDER BY created_at ASC, id ASC`,
  );
  return result.rows;
}

async function insertTrack({
  title,
  objectPath,
  contentType,
  fileSize,
  license,
  uploaderIpHash,
}) {
  const result = await pool.query(
    `INSERT INTO tracks
       (title, object_path, content_type, file_size, license, uploader_ip_hash)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING ${selectTrackColumns()}`,
    [title, objectPath, contentType, fileSize, license, uploaderIpHash],
  );
  return result.rows[0];
}

async function findTrack(id) {
  const result = await pool.query(
    `SELECT ${selectTrackColumns()}
     FROM tracks
     WHERE id = $1`,
    [id],
  );
  return result.rows[0] || null;
}

async function recordVote(id, voterIpHash, vote) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const existing = await client.query(
      `SELECT ${selectTrackColumns()}
       FROM tracks
       WHERE id = $1
       FOR UPDATE`,
      [id],
    );
    const track = existing.rows[0];
    if (!track) {
      await client.query("ROLLBACK");
      return { kind: "not_found" };
    }
    if (track.uploader_ip_hash === voterIpHash) {
      await client.query("ROLLBACK");
      return { kind: "own_track" };
    }
    if (track.approved) {
      await client.query("ROLLBACK");
      return { kind: "already_approved", track };
    }

    try {
      await client.query(
        `INSERT INTO track_votes (track_id, voter_ip_hash, vote)
         VALUES ($1, $2, $3)`,
        [id, voterIpHash, vote],
      );
    } catch (error) {
      if (error && error.code === "23505") {
        await client.query("ROLLBACK");
        return { kind: "already_voted", track };
      }
      throw error;
    }

    const updated = await client.query(
      `UPDATE tracks
       SET votes = votes + CASE WHEN $2 = 'keep' THEN 1 ELSE 0 END,
           approved = CASE
             WHEN $2 = 'keep' AND votes + 1 >= 2 AND admin_approved THEN TRUE
             ELSE approved
           END
       WHERE id = $1
       RETURNING ${selectTrackColumns()}`,
      [id, vote],
    );
    await client.query("COMMIT");
    return { kind: "ok", track: updated.rows[0] };
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}

async function approveTrack(id) {
  const result = await pool.query(
    `UPDATE tracks
     SET admin_approved = TRUE,
         approved = CASE WHEN votes >= 2 THEN TRUE ELSE approved END
     WHERE id = $1
     RETURNING ${selectTrackColumns()}`,
    [id],
  );
  return result.rows[0] || null;
}

async function deleteTrack(id) {
  const result = await pool.query(
    `DELETE FROM tracks
     WHERE id = $1
     RETURNING id, object_path`,
    [id],
  );
  return result.rows[0] || null;
}

module.exports = {
  approveTrack,
  deleteTrack,
  findTrack,
  insertTrack,
  listAdminTracks,
  listTracks,
  pool,
  recordVote,
};