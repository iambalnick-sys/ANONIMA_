const crypto = require("crypto");

const SIDECAR_ENDPOINT = "http://127.0.0.1:1106";

function getPrivateObjectDir() {
  const dir = process.env.PRIVATE_OBJECT_DIR;
  if (!dir) throw new Error("PRIVATE_OBJECT_DIR is not configured.");
  return dir.replace(/\/+$/, "");
}

function parseObjectPath(fullPath) {
  const normalized = fullPath.startsWith("/") ? fullPath : `/${fullPath}`;
  const parts = normalized.split("/");
  if (parts.length < 3 || !parts[1] || !parts.slice(2).join("/")) {
    throw new Error("Invalid object storage path.");
  }
  return { bucketName: parts[1], objectName: parts.slice(2).join("/") };
}

function resolveObjectPath(objectPath) {
  if (
    typeof objectPath !== "string" ||
    !objectPath.startsWith("/objects/") ||
    objectPath.includes("..") ||
    objectPath.includes("\\")
  ) {
    throw new Error("Invalid object path.");
  }

  const entityPath = objectPath.slice("/objects/".length);
  return `${getPrivateObjectDir()}/${entityPath}`;
}

async function signObjectUrl(objectPath, method, ttlSeconds = 900) {
  const { bucketName, objectName } = parseObjectPath(
    resolveObjectPath(objectPath),
  );
  const response = await fetch(
    `${SIDECAR_ENDPOINT}/object-storage/signed-object-url`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        bucket_name: bucketName,
        object_name: objectName,
        method,
        expires_at: new Date(
          Date.now() + ttlSeconds * 1000,
        ).toISOString(),
      }),
      signal: AbortSignal.timeout(30_000),
    },
  );

  if (!response.ok) {
    throw new Error(`Could not sign object URL (${response.status}).`);
  }

  const payload = await response.json();
  if (!payload.signed_url) throw new Error("Object storage returned no URL.");
  return payload.signed_url;
}

async function requestUploadTarget() {
  const objectPath = `/objects/uploads/${crypto.randomUUID()}.mp3`;
  const uploadURL = await signObjectUrl(objectPath, "PUT");
  return { uploadURL, objectPath };
}

async function deleteObject(objectPath) {
  const deleteURL = await signObjectUrl(objectPath, "DELETE", 300);
  const response = await fetch(deleteURL, {
    method: "DELETE",
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok && response.status !== 404) {
    throw new Error(`Could not delete object (${response.status}).`);
  }
}

async function getObjectRedirect(objectPath) {
  return signObjectUrl(objectPath, "GET", 900);
}

async function downloadObject(objectPath) {
  const objectURL = await getObjectRedirect(objectPath);
  const response = await fetch(objectURL, {
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) throw new Error(`Could not read object (${response.status}).`);
  return response;
}

module.exports = {
  deleteObject,
  downloadObject,
  getObjectRedirect,
  requestUploadTarget,
};