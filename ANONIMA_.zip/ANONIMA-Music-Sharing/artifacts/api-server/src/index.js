const crypto = require("crypto");
const cookieParser = require("cookie-parser");
const express = require("express");
const {
  approveTrack,
  deleteTrack,
  findTrack,
  insertTrack,
  listAdminTracks,
  listTracks,
  pool,
  recordVote,
} = require("./database");
const {
  deleteObject,
  downloadObject,
  getObjectRedirect,
  requestUploadTarget,
} = require("./object-storage");

const app = express();
const port = Number(process.env.PORT || 3000);
const MAX_FILE_SIZE = 20 * 1024 * 1024;
const INVALID_MP3_ERROR = "Only original mp3s allowed";
const ALLOWED_MIME_TYPES = new Set(["audio/mpeg", "audio/mp3"]);
const LICENSES = new Set([
  "Tutti i diritti riservati",
  "CC BY",
  "CC BY-NC",
  "CC BY-NC-SA",
  "Remix non ufficiale",
]);
const ADMIN_COOKIE = "anonima_admin";

app.set("trust proxy", true);
app.use(cookieParser());
app.use(express.json({ limit: "256kb" }));

app.get("/api/healthz", (_request, response) => {
  response.json({ status: "ok", service: "anonima" });
});

app.get("/api/tracks", async (request, response, next) => {
  try {
    const rows = await listTracks(ipHash(request));
    const mapped = rows.map(toTrack);
    response.json({
      approved: mapped.filter((track) => track.approved),
      pending: mapped.filter((track) => !track.approved),
    });
  } catch (error) {
    next(error);
  }
});

app.post("/api/storage/uploads/request-url", async (request, response, next) => {
  try {
    const { name, size, contentType } = request.body || {};
    if (
      typeof name !== "string" ||
      name.length < 1 ||
      name.length > 255 ||
      !Number.isInteger(size) ||
      size < 1 ||
      size > MAX_FILE_SIZE ||
      typeof contentType !== "string" ||
      !ALLOWED_MIME_TYPES.has(contentType)
    ) {
      response.status(400).json({ error: INVALID_MP3_ERROR });
      return;
    }

    const { uploadURL, objectPath } = await requestUploadTarget();
    response.json({
      uploadURL,
      objectPath,
      metadata: { name, size, contentType },
    });
  } catch (error) {
    next(error);
  }
});

app.post("/api/upload", async (request, response, next) => {
  let objectPath;
  try {
    const {
      title,
      objectPath: requestedPath,
      contentType,
      size,
      license,
    } = request.body || {};
    objectPath = requestedPath;

    if (
      typeof title !== "string" ||
      title.trim().length < 1 ||
      title.trim().length > 120 ||
      !isValidObjectPath(objectPath) ||
      !Number.isInteger(size) ||
      size < 1 ||
      size > MAX_FILE_SIZE ||
      typeof contentType !== "string" ||
      !ALLOWED_MIME_TYPES.has(contentType) ||
      typeof license !== "string" ||
      !LICENSES.has(license)
    ) {
      response.status(400).json({ error: INVALID_MP3_ERROR });
      return;
    }

    const file = await downloadObject(objectPath);
    const actualContentType = (file.headers.get("content-type") || "")
      .split(";")[0]
      .trim()
      .toLowerCase();
    const contentLength = Number(file.headers.get("content-length") || 0);
    const bytes = Buffer.from(await file.arrayBuffer());

    if (
      !ALLOWED_MIME_TYPES.has(actualContentType) ||
      (contentLength > MAX_FILE_SIZE && contentLength > 0) ||
      bytes.length > MAX_FILE_SIZE ||
      !hasMp3Magic(bytes)
    ) {
      await deleteObject(objectPath).catch(() => {});
      response.status(400).json({ error: INVALID_MP3_ERROR });
      return;
    }

    const row = await insertTrack({
      title: title.trim(),
      objectPath,
      contentType: "audio/mpeg",
      fileSize: bytes.length,
      license,
      uploaderIpHash: ipHash(request),
    });
    response.status(201).json(toTrack(row));
  } catch (error) {
    if (objectPath && isValidObjectPath(objectPath)) {
      await deleteObject(objectPath).catch(() => {});
    }
    next(error);
  }
});

app.post("/api/vote/:id", (request, response, next) =>
  handleUserVote(request, response, next, "keep"),
);

app.post("/api/skip/:id", (request, response, next) =>
  handleUserVote(request, response, next, "skip"),
);

app.post("/api/report/:id", (request, response, next) =>
  handleUserVote(request, response, next, "skip"),
);

app.post("/api/admin/login", async (request, response, next) => {
  try {
    const configuredPassword = process.env.ANONIMA_ADMIN_PASSWORD;
    const password = request.body && request.body.password;
    if (!configuredPassword) {
      response.status(503).json({ error: "Admin secret is not configured." });
      return;
    }
    if (!safeEqualSecret(password, configuredPassword)) {
      response.status(401).json({ error: "Invalid admin password." });
      return;
    }

    response.cookie(ADMIN_COOKIE, createAdminSession(), {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 8 * 60 * 60 * 1000,
      path: "/",
    });
    response.json({ authenticated: true });
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/logout", (_request, response) => {
  response.clearCookie(ADMIN_COOKIE, { path: "/" });
  response.json({ authenticated: false });
});

app.get("/api/admin/tracks", requireAdmin, async (_request, response, next) => {
  try {
    const rows = await listAdminTracks();
    response.json({ tracks: rows.map(toTrack) });
  } catch (error) {
    next(error);
  }
});

app.post(
  "/api/admin/tracks/:id/approve",
  requireAdmin,
  async (request, response, next) => {
    try {
      const id = parseId(request.params.id);
      const row = id ? await approveTrack(id) : null;
      if (!row) {
        response.status(404).json({ error: "Track not found." });
        return;
      }
      response.json({
        message: row.approved
          ? "Track approved and live."
          : "Admin approval saved. Two KEEPs are still required.",
        track: toTrack(row),
      });
    } catch (error) {
      next(error);
    }
  },
);

app.post(
  "/api/admin/tracks/:id/reject",
  requireAdmin,
  (request, response, next) => removeAdminTrack(request, response, next),
);

app.delete(
  "/api/admin/tracks/:id",
  requireAdmin,
  (request, response, next) => removeAdminTrack(request, response, next),
);

app.get("/api/storage/objects/*objectPath", async (request, response, next) => {
  try {
    const raw = request.params.objectPath;
    const pathPart = Array.isArray(raw) ? raw.join("/") : raw;
    if (!pathPart || pathPart.includes("..") || pathPart.includes("\\")) {
      response.status(404).json({ error: "Object not found." });
      return;
    }
    const objectUrl = await getObjectRedirect(`/objects/${pathPart}`);
    response.redirect(objectUrl);
  } catch (error) {
    next(error);
  }
});

app.use((error, _request, response, _next) => {
  response.status(500).json({ error: "Something went wrong." });
});

async function handleUserVote(request, response, next, vote) {
  try {
    const id = parseId(request.params.id);
    if (!id) {
      response.status(404).json({ error: "Track not found." });
      return;
    }

    const result = await recordVote(id, ipHash(request), vote);
    if (result.kind === "not_found") {
      response.status(404).json({ error: "Track not found." });
      return;
    }
    if (result.kind === "own_track") {
      response.status(403).json({ error: "You cannot vote on your own upload." });
      return;
    }
    if (result.kind === "already_voted") {
      response.status(409).json({ error: "You already voted on this track." });
      return;
    }
    if (result.kind === "already_approved") {
      response.status(400).json({ error: "This track is already live." });
      return;
    }

    response.json({
      message: vote === "keep" ? "KEEP recorded." : "SKIP recorded.",
      track: toTrack(result.track),
    });
  } catch (error) {
    next(error);
  }
}

async function removeAdminTrack(request, response, next) {
  try {
    const id = parseId(request.params.id);
    const row = id ? await findTrack(id) : null;
    if (!row) {
      response.status(404).json({ error: "Track not found." });
      return;
    }
    await deleteObject(row.object_path).catch(() => {});
    await deleteTrack(id);
    response.json({ message: "Track deleted forever.", id });
  } catch (error) {
    next(error);
  }
}

function requireAdmin(request, response, next) {
  if (!isAdminSession(request.cookies[ADMIN_COOKIE])) {
    response.status(401).json({ error: "Admin authentication required." });
    return;
  }
  next();
}

function createAdminSession() {
  const payload = Buffer.from(
    JSON.stringify({ exp: Date.now() + 8 * 60 * 60 * 1000 }),
  ).toString("base64url");
  return `${payload}.${signSession(payload)}`;
}

function isAdminSession(value) {
  if (typeof value !== "string") return false;
  const separator = value.lastIndexOf(".");
  if (separator < 1) return false;
  const payload = value.slice(0, separator);
  const signature = value.slice(separator + 1);
  if (!safeEqualSecret(signature, signSession(payload))) return false;
  try {
    return JSON.parse(Buffer.from(payload, "base64url").toString()).exp > Date.now();
  } catch (_error) {
    return false;
  }
}

function signSession(payload) {
  if (!process.env.SESSION_SECRET) throw new Error("SESSION_SECRET is required.");
  return crypto
    .createHmac("sha256", process.env.SESSION_SECRET)
    .update(payload)
    .digest("base64url");
}

function safeEqualSecret(left, right) {
  if (typeof left !== "string" || typeof right !== "string") return false;
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);
  return (
    leftBuffer.length === rightBuffer.length &&
    crypto.timingSafeEqual(leftBuffer, rightBuffer)
  );
}

function ipHash(request) {
  if (!process.env.SESSION_SECRET) throw new Error("SESSION_SECRET is required.");
  const ip = String(request.ip || request.socket.remoteAddress || "unknown")
    .replace(/^::ffff:/, "")
    .trim();
  return crypto
    .createHmac("sha256", process.env.SESSION_SECRET)
    .update(ip)
    .digest("hex");
}

function isValidObjectPath(value) {
  return (
    typeof value === "string" &&
    value.startsWith("/objects/uploads/") &&
    value.endsWith(".mp3") &&
    !value.includes("..") &&
    !value.includes("\\")
  );
}

function parseId(value) {
  const id = Number(value);
  return Number.isInteger(id) && id > 0 ? id : null;
}

function hasMp3Magic(bytes) {
  if (bytes.length >= 3 && bytes.subarray(0, 3).toString() === "ID3") {
    return true;
  }
  return (
    bytes.length >= 2 &&
    bytes[0] === 0xff &&
    (bytes[1] & 0xe0) === 0xe0 &&
    (bytes[1] & 0x06) !== 0
  );
}

function toTrack(row) {
  return {
    id: row.id,
    title: row.title,
    objectPath: row.object_path,
    audioUrl: `/api/storage/objects/${row.object_path.slice("/objects/".length)}`,
    license: row.license,
    votes: row.votes,
    adminApproved: row.admin_approved,
    approved: row.approved,
    viewerVote: row.viewer_vote || null,
    createdAt: new Date(row.created_at).toISOString(),
  };
}

const server = app.listen(port, () => {
  process.stdout.write(`ANONIMA API listening on port ${port}\n`);
});

process.on("SIGTERM", async () => {
  await pool.end();
  server.close(() => process.exit(0));
});