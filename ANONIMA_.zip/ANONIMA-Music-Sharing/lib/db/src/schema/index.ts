import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const tracksTable = pgTable("tracks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  objectPath: text("object_path").notNull().unique(),
  contentType: text("content_type").notNull(),
  fileSize: integer("file_size").notNull(),
  license: text("license")
    .notNull()
    .default("Tutti i diritti riservati"),
  uploaderIpHash: text("uploader_ip_hash").notNull().default(""),
  votes: integer("votes").notNull().default(0),
  adminApproved: boolean("admin_approved").notNull().default(false),
  approved: boolean("approved").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const trackVotesTable = pgTable(
  "track_votes",
  {
    id: serial("id").primaryKey(),
    trackId: integer("track_id")
      .notNull()
      .references(() => tracksTable.id, { onDelete: "cascade" }),
    voterIpHash: text("voter_ip_hash").notNull(),
    vote: text("vote").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    trackVoterUnique: uniqueIndex("track_votes_track_voter_unique").on(
      table.trackId,
      table.voterIpHash,
    ),
  }),
);